package previsaoclima;

public class PrevisaoClima {

    public static void main(String[] args) throws Exception {

        String caminhoDados = "weather.arff";

        PrevisaoTempo previsao = new PrevisaoTempo();
        previsao.setVisible(true);

        ControllerPrevisao exemplo = new ControllerPrevisao(caminhoDados, previsao);//controler

    }

}
