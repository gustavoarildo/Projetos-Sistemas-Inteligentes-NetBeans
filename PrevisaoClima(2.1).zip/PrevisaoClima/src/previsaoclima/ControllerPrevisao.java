package previsaoclima;

import java.util.Random;
import weka.core.Instances;
import weka.core.Instance;
import weka.core.converters.ConverterUtils.DataSource;
import weka.classifiers.trees.J48;
import weka.classifiers.Evaluation;
import weka.classifiers.lazy.IBk;
import weka.core.Attribute;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javax.swing.JOptionPane.showMessageDialog;

public class ControllerPrevisao {

    int i;
    private String caminhoDados;
    private Instances dados;
    private PrevisaoTempo previsao;

    //Constructor
    public ControllerPrevisao(String caminhoDados, PrevisaoTempo previsao) {
        this.caminhoDados = caminhoDados;
        this.previsao = previsao;
        this.previsao.addobservaAcoes(new observaAcoes());

    }

    public void leDados() throws Exception {
        DataSource fonte = new DataSource(caminhoDados);
        dados = fonte.getDataSet();
        if (dados.classIndex() == -1) {
            dados.setClassIndex(dados.numAttributes() - 1);
        }

    }

    public void imprimeDados() {
        previsao.getjTextArea1().setText("");
        for (i = 0; i < dados.numInstances(); i++) {
            Instance atual = dados.instance(i);
            System.out.println((i + 1) + ":" + atual + "\n");

            previsao.getjTextArea1().append((i + 1) + ":" + atual + "\n");

        }

    }

    public void arvoreDeDecisaoJ48() throws Exception {
        J48 tree = new J48();
        tree.buildClassifier(dados);
        System.out.println(tree);
        System.out.println("Avaliacao inicial: \n");
        Evaluation avaliacao;
        avaliacao = new Evaluation(dados);
        avaliacao.evaluateModel(tree, dados);
        System.out.println("--> Instancias corretas: " + avaliacao.correct() + "\n");
        System.out.println("Avaliacao cruzada: \n");
        Evaluation avalcruzada;
        avalcruzada = new Evaluation(dados);
        avalcruzada.crossValidateModel(tree, dados, 10, new Random(1));
        System.out.println("--> Instancias corretas CV: " + avalcruzada.correct() + "\n");

        previsao.getjTextArea1().append(tree.toString());
        showMessageDialog(null, "Avaliacao inicial: \n--> Instancias corretas: " + avaliacao.correct() + "\nAvaliacao cruzada: \n--> Instancias corretas CV: " + avalcruzada.correct() + "\n");

    }

    public void InstanceBased(int vizinhos, float outlook, float temperature, float humidity, float windy) throws Exception {
        IBk k3 = new IBk(vizinhos);
        k3.buildClassifier(dados);

        Instance inst = dados.instance(5);
        inst.setDataset(dados);

        inst.setValue(0, outlook);
        inst.setValue(1, temperature);
        inst.setValue(2, humidity);
        inst.setValue(3, windy);
        double pred = k3.classifyInstance(inst);

        System.out.println("Predição: " + pred);

        Attribute a = dados.attribute(4);
        String predClass = a.value((int) pred);
        System.out.println("Predicao: " + predClass);

        showMessageDialog(null, "Play? \nPredicao: " + predClass);
        
        

    }

    public void executaAlgoritmo(boolean radioBotao1, boolean radioBotao2) throws IOException, Exception {

        if (radioBotao1) {
            System.out.println("IBK");

            int i1 = Integer.parseInt(previsao.getjTextField1().getText());
            float i2 = Float.parseFloat(previsao.getjTextField2().getText());
            float i3 = Float.parseFloat(previsao.getjTextField3().getText());
            float i4 = Float.parseFloat(previsao.getjTextField4().getText());
            float i5 = Float.parseFloat(previsao.getjTextField5().getText());

            leDados();
            imprimeDados();
            InstanceBased(i1, i2, i3, i4, i5);
        }

        if (radioBotao2) {

            System.out.println("J-48");

            leDados();
            imprimeDados();
            arvoreDeDecisaoJ48();

        }

    }

    public class observaAcoes implements ActionListener {

        int estadoDeEscolhaOuConfirmacao = 0;

        public void actionPerfomed(ActionEvent e) {

        }

        @Override
        public void actionPerformed(ActionEvent e) {

            boolean radioBotao1, radioBotao2;

            try {
                if (e.getActionCommand().equals(previsao.getjButton1().getActionCommand())) {

                    radioBotao1 = previsao.getjRadioButton1().isSelected();
                    radioBotao2 = previsao.getjRadioButton2().isSelected();

                    if (estadoDeEscolhaOuConfirmacao == 1) {
                        executaAlgoritmo(radioBotao1, radioBotao2);
                        estadoDeEscolhaOuConfirmacao = 0;
                        previsao.getjTextField1().setEnabled(Boolean.FALSE);
                        previsao.getjTextField2().setEnabled(Boolean.FALSE);
                        previsao.getjTextField3().setEnabled(Boolean.FALSE);
                        previsao.getjTextField4().setEnabled(Boolean.FALSE);
                        previsao.getjTextField5().setEnabled(Boolean.FALSE);

                        showMessageDialog(null, "Algoritimo executado");

                    } else {

                        estadoDeEscolhaOuConfirmacao = 1;
                    }
                }
                if (previsao.getjRadioButton1().isSelected() && estadoDeEscolhaOuConfirmacao == 1) {
                    previsao.getjTextField1().setEnabled(true);

                    previsao.getjTextField2().setEnabled(Boolean.TRUE);
                    previsao.getjTextField3().setEnabled(Boolean.TRUE);
                    previsao.getjTextField4().setEnabled(Boolean.TRUE);
                    previsao.getjTextField5().setEnabled(Boolean.TRUE);
                }
                if (previsao.getjRadioButton2().isSelected() && estadoDeEscolhaOuConfirmacao == 1) {
                    previsao.getjTextField1().setEnabled(false);

                    previsao.getjTextField2().setEnabled(Boolean.FALSE);
                    previsao.getjTextField3().setEnabled(Boolean.FALSE);
                    previsao.getjTextField4().setEnabled(Boolean.FALSE);
                    previsao.getjTextField5().setEnabled(Boolean.FALSE);
                }
            } catch (NumberFormatException ex) {
                System.out.println(ex);
                previsao.displayErrorMessage(" Voce precisa selecionar um dos algoritmos ");

            } catch (IOException ex) {
                Logger.getLogger(ControllerPrevisao.class.getName()).log(Level.SEVERE, null, ex);
            } catch (Exception ex) {
                Logger.getLogger(ControllerPrevisao.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

}
